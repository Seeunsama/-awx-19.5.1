# Retrieve Information about the current User

Make a GET request to retrieve user information about the current user.

One result should be returned containing the following fields:

{% include "api/_result_fields_common.md" %}

Use the primary URL for the user (/api/v2/users/N/) to modify the user.
