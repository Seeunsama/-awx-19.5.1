---
name: "✨ Feature request"
about: Suggest an idea for this project

---
<!-- Issues are for **concrete, actionable bugs and feature requests** only - if you're just asking for debugging help or technical support, please use:

- http://web.libera.chat/?channels=#ansible-awx
- https://groups.google.com/forum/#!forum/awx-project

We have to limit this because of limited volunteer time to respond to issues! -->

##### ISSUE TYPE
 - Feature Idea

##### SUMMARY
<!-- Briefly describe the problem or desired enhancement. -->
